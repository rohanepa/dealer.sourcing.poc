﻿namespace Dealer.Sourcing.Infrastructure.Models
{
    public class Appraisal
    {
    }
}
