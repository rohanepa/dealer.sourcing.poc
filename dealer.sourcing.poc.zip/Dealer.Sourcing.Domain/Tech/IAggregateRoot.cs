﻿namespace Dealer.Sourcing.Domain.Tech
{
    public interface IAggregateRoot
    {
    }
}
