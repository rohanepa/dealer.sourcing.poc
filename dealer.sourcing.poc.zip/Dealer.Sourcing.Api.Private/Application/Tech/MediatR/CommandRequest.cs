﻿using MediatR;

namespace Dealer.Sourcing.Api.Private.Application.Tech.MediatR
{
    public class CommandRequest : IRequest<IResponse>
    {
    }
}
